package com.sella.chatbots.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpRequest;
import org.omg.PortableInterceptor.SUCCESSFUL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sella.chatbots.bo.RequestBO;
import com.sella.chatbots.bo.ResponseBO;
import com.sella.chatbots.utils.ApiAICall;
import com.sella.chatbots.utils.ChatUtils;
import com.sella.chatbots.utils.ChunkerUtil;



@Controller
@RequestMapping("/ws")
public class IndexController
{

    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);
    public static String TOKEN = "";

    @RequestMapping(value="/processtext",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody ResponseBO  displayRequestPage(final @RequestBody RequestBO requestmsg)
    {
        return new ChatUtils().PROCESSMSG(requestmsg);

    }
    
    @RequestMapping(value="/settoken",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody String  settoken(final @RequestBody String token)
    {
    	IndexController.TOKEN = token;
        return IndexController.TOKEN;

    }
    
    @RequestMapping(value="/cdbots",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody String  cdbots( final @RequestBody String token,HttpServletRequest  request)
    {
    	System.out.println("-------->"+request.getSession().getId());
    	new ApiAICall().postHttp(ApiAICall.CDURL, null);
    	return "success";
    }
    
    @RequestMapping(value="/getbill",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody String  getbill(final @RequestBody String token)
    {
    	new ApiAICall().getHttp(ApiAICall.CDURL,null);
    	return "success";

    }
    
    @RequestMapping(value="/paybill",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody String  paybill(final @RequestBody String token)
    {
    	return "success";

    }
    
 
 

}
