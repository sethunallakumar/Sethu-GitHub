package com.sella.chatbots.bo;

public class CDRequestBO {
	
	private String identificativoOrdinante;

    private String codiceSIAAzienda;

    private String importo;

    private String contoordinate;

    private String codiceSIAdescrizione;

    private String paymentDate;
    
    public CDRequestBO(){}

	public CDRequestBO(String identificativoOrdinante, String codiceSIAAzienda,
			String importo, String contoordinate, String codiceSIAdescrizione,
			String paymentDate) {
		super();
		this.identificativoOrdinante = identificativoOrdinante;
		this.codiceSIAAzienda = codiceSIAAzienda;
		this.importo = importo;
		this.contoordinate = contoordinate;
		this.codiceSIAdescrizione = codiceSIAdescrizione;
		this.paymentDate = paymentDate;
	}

	public String getIdentificativoOrdinante() {
		return identificativoOrdinante;
	}

	public void setIdentificativoOrdinante(String identificativoOrdinante) {
		this.identificativoOrdinante = identificativoOrdinante;
	}

	public String getCodiceSIAAzienda() {
		return codiceSIAAzienda;
	}

	public void setCodiceSIAAzienda(String codiceSIAAzienda) {
		this.codiceSIAAzienda = codiceSIAAzienda;
	}

	public String getImporto() {
		return importo;
	}

	public void setImporto(String importo) {
		this.importo = importo;
	}

	public String getContoordinate() {
		return contoordinate;
	}

	public void setContoordinate(String contoordinate) {
		this.contoordinate = contoordinate;
	}

	public String getCodiceSIAdescrizione() {
		return codiceSIAdescrizione;
	}

	public void setCodiceSIAdescrizione(String codiceSIAdescrizione) {
		this.codiceSIAdescrizione = codiceSIAdescrizione;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

    

}
