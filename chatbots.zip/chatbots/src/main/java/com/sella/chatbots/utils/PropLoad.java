package com.sella.chatbots.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropLoad {
	
	private static PropLoad PROPLOAD;
	
	private Properties prop;


	public static PropLoad GETINSTANCE() {
		if (PROPLOAD == null) {
			PROPLOAD = new PropLoad();
		}
		return PROPLOAD;
	}
	
	public Properties getProps() {
		if(this.prop == null){
			prop = new Properties();
			InputStream input = null;
			try {
				// load a properties file
				prop.load(getClass().getClassLoader().getResourceAsStream("periodProperties.properties"));
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return this.prop;
	}
	

}
