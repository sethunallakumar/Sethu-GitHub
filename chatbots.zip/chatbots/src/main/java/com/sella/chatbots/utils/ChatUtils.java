package com.sella.chatbots.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sella.chatbots.bo.ApiResponse;
import com.sella.chatbots.bo.ApiResponseParameters;
import com.sella.chatbots.bo.RequestBO;
import com.sella.chatbots.bo.Response;
import com.sella.chatbots.bo.ResponseBO;
import com.sella.chatbots.enums.ACTION;

public class ChatUtils {
	public static ResponseBO PROCESSMSG(RequestBO input){
		String query = input.getQuery().toLowerCase();
		String parameter = "";
		Response response = null;
		System.out.println("Query : "+input.getQuery());
		System.out.println("PARA : "+input.getParameter());
		if(input.getParameter() !=null && input.getParameter().length()>0){
			parameter = input.getParameter().toLowerCase();
			if(input.getParameter().toLowerCase().contains("yes")){
				response = new Response(ACTION.MSG, "Your telephone bill has been paid. Transaction completed.  Currently you have 19700 euro in account. Anything else you want?", null, false, null,null);
			}else if(input.getParameter().toLowerCase().contains("yes pay")){
				response = new Response(ACTION.MSG, "Your telephone bill has been paid. Transaction completed.  Currently you have 19200 euro in account. Anything else you want?", null, false, null,null);
			}else if(input.getParameter().toLowerCase().contains("no")){
				response = new Response(ACTION.MSG, "Request Cancelled", null, false, null,null);
			}else if(input.getParameter().toLowerCase().contains("telephone bill")){
				response = new Response(ACTION.CONFIRM, "Do you confirm to pay 200 euro to Telephone bill?", null, false, null,null);
			}else{
				response = new Response(ACTION.MSG, "Provide Valid Response", null, false, null,null);
			}
		}
		if(query.contains("welcome")){
			response = new Response(ACTION.MSG, "Welcome, I am sella Assistant. How can i help you?", null, false, null,null);
		}
		else if(query.contains("current balance")){
			response = new Response(ACTION.MSG, "Your current balance is 20000 euro. Anything else you need?", null, false, null,null);
		}
		else if(query.contains("pay 300 euro")  && parameter.contains("yes")){
			response = new Response(ACTION.MSG, "Your telephone bill has been paid. Transaction completed.  Currently you have 19700 euro in account. Anything else you want?", null, false, null,null);
		}
		else if(query.contains("pay 300 euro")  && parameter.contains("telephone bill")){
			response = new Response(ACTION.MSG, "Please provide your Identification No for Telephone Bill?", null, false, null,null);
		}
		else if(query.contains("pay 300 euro")){
			List<String> suggestions = new ArrayList<String>();
			suggestions.add("Telephone Bill");
			suggestions.add("EB Bill");
			suggestions.add("Gas Bill");
			response = new Response(ACTION.SUGGESTION, "Your transaction is initiated. Please select which bill i have to pay?", suggestions, false, null,null);
		}
		else if(query.contains("Telephone Bill") && parameter.contains("yes")){
			response = new Response(ACTION.MSG, "Your telephone bill has been paid. Transaction completed.  Currently you have 19700 euro in account. Anything else you want?", null, false, null,null);
		}
		else if(parameter.contains("Telephone Bill")){
			response = new Response(ACTION.CONFIRM, "Please provide your Identification No for Telephone Bill?", null, false, null,null);
		}
		else if(query.contains("aa918")){
			response = new Response(ACTION.MSG, "Your telephone bill has been paid. Transaction completed.  Currently you have 19800 euro in account. Anything else you want?", null, false, null,null);
		}
		else if(query.contains("show my last 10")){
			List<String> transactions = new ArrayList<String>();
			transactions.add("To Airtel as Telephone Bill of 200 on 25/10/2016");
			transactions.add("To TNEB as EB Bill of 1000 on 05/10/2016");
			transactions.add("To Suresh as Shopping of 2000 on 01/10/2016");
			transactions.add("To Sethu as Shopping of 649 on 08/09/2016");
			transactions.add("To Gas Agency as Gas Bill of 1600 on 08/09/2016");
			transactions.add("To Karthika as Shopping of 843 on 24/08/2016");
			transactions.add("To Senthil as  Shopping of 760 on 11/08/2016");
			transactions.add("To Airtel as Telephone Bill of 200 on 02/08/2016");
			transactions.add("To TNEB as EB Bill of 1320 on 02/08/2016");
			transactions.add("To Gas Agency as Gas Bill of 1600 on 01/08/2016");
			response = new Response(ACTION.MSG, "Here is the last 10 transactions you have done", null, false, transactions,null);
		}
		else if(query.contains("august month transaction")){
			List<String> transactions = new ArrayList<String>();
			transactions.add("To Karthika as Shopping of 843 on 24/08/2016");
			transactions.add("To Senthil as  Shopping of 760 on 11/08/2016");
			transactions.add("To Airtel as Telephone Bill of 200 on 02/08/2016");
			transactions.add("To TNEB as EB Bill of 1320 on 02/08/2016");
			transactions.add("To Gas Agency as Gas Bill of 1600 on 01/08/2016");
			response = new Response(ACTION.MSG, "Here is the August month transaction details", null, false, transactions,null);
		}
		else if(query.contains("pay eb bill")){
			response = new Response(ACTION.MSG, "How much i have to pay?", null, false, null,null);
		}
		else if(query.contains("200 euro") && parameter.contains("yes")){
			response = new Response(ACTION.MSG, "Your EB Bill has been paid. Transaction completed.  Currently you have 19500 euro in account. Anything else you want?", null, false, null,null);
		}
		else if(query.contains("200 euro")){
			response = new Response(ACTION.CONFIRM, "Are you sure you want to pay 200 euro to EB bill.", null, false, null,null);
		}
		else if(query.equals("Yes")){
			response = new Response(ACTION.MSG, "Your Eb bill has been paid. Transaction completed.  Currently you have 19550 euro in account. Anything else you want?", null, false, null,null);
		}
		else if(query.contains("i want trader account")){
			List<String> links = new ArrayList<String>();
			links.add("https://www.sella.it/onboarding/fe/#/start/CONTOTRADER");
			response = new Response(ACTION.LINK, "Please use below link to request a trader account. Anything else you need?", null, false, null,links);
		}
		else if(query.contains("no thanks")){
			response = new Response(ACTION.MSG, "Thank you for using Sella Assistant. Have a nice day", null, false, null,null);
		}
		
		ResponseBO responseBO = new ResponseBO(input, input.getSessionId(), input.getLoginSessionId(), response);
		return responseBO;
		
	}
	/*public static ResponseBO PROCESSMSG(RequestBO input){
		String query = input.getQuery().toLowerCase();
		Response response = null;
		if(input.getParameter() !=null && input.getParameter().length()>0){
			if(input.getParameter().toLowerCase().contains("yes")){
				response = new Response(ACTION.MSG, "Request Accepted", null, false, null,null);
			}else if(input.getParameter().toLowerCase().contains("no")){
				response = new Response(ACTION.MSG, "Request Cancelled", null, false, null,null);
			}else{
				response = new Response(ACTION.MSG, "Provide Valid Response", null, false, null,null);
			}
		}else if(query.contains("welcome")){
			response = new Response(ACTION.MSG, "Ciao, This is Sella Assistant", null, false, null,null);
		}else if(query.contains("bill payments")){
			List<String> suggestions = new ArrayList<String>();
			suggestions.add("ELectric Bill");
			suggestions.add("Telephone Bill");
			response = new Response(ACTION.SUGGESTION, "Please select the Merchant", suggestions, false, null,null);
		}else if(query.contains("balance")){
			response = new Response(ACTION.MSG, "your balance is 5000 euro", null, false, null,null);
		}else if(query.contains("transaction")){
			ApiResponse apiResponse = new ApiAICall().getHttpResult(query);
			ApiResponseParameters responseParameters = apiResponse.getResult().getParameters();
			response = new Response(ACTION.MSG, "your Transaction List", null, true, null,null);
			response = new TransUtil().getTransList(response,responseParameters.getFromdate(),responseParameters.getTodate(),responseParameters.getDuration(),responseParameters.getNoofduration());
		}else if(query.contains("confirm")){
			response = new Response(ACTION.CONFIRM, "Are you sure to Transfer", null, false, null,null);
		}else if(query.contains("link")){
			List<String> lists = new ArrayList<String>();
			lists.add("http://jsonlint.com/");
			lists.add("http://google.com/");
			response = new Response(ACTION.LINK, "Go to Below Link", null, false, null,lists);
		}else{
			response = new Response(ACTION.MSG, "I am bit confused,please be specific", null, false, null,null);
		}
		ResponseBO responseBO = new ResponseBO(input, input.getSessionId(), input.getLoginSessionId(), response);
		return responseBO;
		
	}*/
	
	private static Date stringToDate(String date_s,Boolean isToDate){
		SimpleDateFormat dt = new SimpleDateFormat("yyyyy-MM-dd");
		Date date = null;
		try {
			date = dt.parse(date_s);
			if(isToDate){
				date.setHours(23);
				date.setMinutes(59);
				date.setSeconds(59);
			}else{
				date.setHours(0);
				date.setMinutes(0);
				date.setSeconds(0);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(date);
		return date;
	}
	
	public static String dateToString(Date date){
		SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
		String date_s = dt.format(date);
		return date_s;
	}

}
