package com.sella.chatbots.test;

import com.sella.chatbots.utils.ChunkerUtil;

public class ChunkerTest {
	
	public static void main(String args[]){
		ChunkerUtil.PROCESSMSG("Hi . how are you. i need August month Transcation details");
	}

}
